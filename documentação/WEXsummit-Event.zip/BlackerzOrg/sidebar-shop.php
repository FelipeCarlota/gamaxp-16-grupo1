<?php
/*	
*	---------------------------------------------------------------------
*	MNKY Default page sidebar
*	--------------------------------------------------------------------- 
*/
?>

	<div class="page-sidebar">
		<div class="widget-area">
			<?php dynamic_sidebar( 'shop-widget-area' ); ?>
		</div>
	</div><!-- .page-sidebar -->